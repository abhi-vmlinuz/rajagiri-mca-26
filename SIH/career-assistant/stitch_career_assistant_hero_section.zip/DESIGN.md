---
name: Career Assistant Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#464555'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#4648d4'
  on-secondary: '#ffffff'
  secondary-container: '#6063ee'
  on-secondary-container: '#fffbff'
  tertiary: '#7e3000'
  on-tertiary: '#ffffff'
  tertiary-container: '#a44100'
  on-tertiary-container: '#ffd2be'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb695'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  display:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  xxl: 64px
  section: 104px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: auto
---

## Brand & Style
The design system for this career guidance platform is built upon the pillars of clarity, encouragement, and professional growth. It utilizes a **Modern Corporate** style that leans heavily into **Minimalism** to reduce cognitive load during high-stakes career decisions.

The aesthetic is "Light and Airy," characterized by expansive white space that allows AI-generated insights to breathe. By avoiding "cold corporate" tropes, the system achieves a premium, approachable feel through soft geometry and a high-fidelity finish. The emotional response should be one of calm confidence—reassuring users that their professional future is in capable hands.

## Colors
The palette is intentionally restrained to maintain focus on content. 
- **Primary Indigo (#4F46E5):** Used exclusively for primary actions, progress indicators, and active states. It signals momentum and trust.
- **Surface Strategy:** Use absolute white (#FFFFFF) for the primary content cards and containers to create a sense of "lift" against the off-white (#FAFAFA) page background.
- **Typography Tones:** Use Charcoal (#1F2937) for all headings to ensure high contrast. Use secondary grays for metadata and helper text to establish a clear information hierarchy.

## Typography
The system uses **Inter** for its systematic, utilitarian precision and modern feel. 

- **Headlines:** Use tight letter-spacing on larger sizes to create a "premium editorial" look. Headlines should always be Charcoal (#1F2937).
- **Body:** Prioritize line height (1.5x minimum) to ensure long-form career advice or resume feedback is easily scannable.
- **Labels:** Use medium weights for interactive elements like buttons and navigation items to distinguish them from static body text.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy for desktop (1200px max-width) to maintain a curated, professional feel, while transitioning to a fluid model for mobile devices.

- **The Breathable Rhythm:** Use `xxl` (64px) spacing between major content sections to reinforce the "airy" brand personality. 
- **Internal Padding:** Cards and containers should never have less than `lg` (24px) padding to ensure the AI-driven data doesn't feel cramped.
- **Grid:** On desktop, use a 12-column grid with 24px gutters. On mobile, use a single column with 16px side margins.

## Elevation & Depth
Depth is created through **Tonal Layers** and **Ambient Shadows** rather than harsh borders.

- **Main Surface:** The background sits at the lowest level (#FAFAFA).
- **Cards & Modules:** These use #FFFFFF and a "Soft Float" shadow. The shadow should be highly diffused: `y: 4px, blur: 20px, color: rgba(31, 41, 55, 0.05)`.
- **Interactions:** When a user hovers over an interactive card, the shadow should slightly deepen (`blur: 30px, opacity: 0.08`) and the element should translate -2px on the Y-axis to provide tactile feedback.
- **Borders:** Use a very faint 1px border (#F3F4F6) only when necessary to define boundaries on white-on-white layouts.

## Shapes
The shape language is friendly and approachable, utilizing large radii to soften the professional tone.

- **Interactive Elements:** Buttons and Input fields use a 12px radius, creating a modern, "squircle-adjacent" appearance that feels comfortable to click.
- **Containers:** Large cards and AI chat bubbles use a 16px radius to establish a distinct visual container for data.
- **Avatars:** Use full circles for user and AI profile images to provide a humanizing contrast to the geometric layout.

## Components
- **Buttons:** The primary button is Indigo (#4F46E5) with white text. It features 12px rounded corners and a subtle 2px vertical offset shadow to feel "pressable."
- **Input Fields:** Use a subtle light-gray background (#F9FAFB) for the field itself, with a 12px radius. On focus, the border should transition to Primary Indigo.
- **Career Cards:** These are the heart of the UI. Use 16px padding, white backgrounds, and the "Soft Float" shadow.
- **Progress Steppers:** Use the Primary Indigo for completed steps and a soft Indigo tint (#E0E7FF) for upcoming steps to keep the tone optimistic.
- **AI Chat Bubbles:** The AI's responses should be styled in a soft Indigo tint to differentiate from the user's white chat bubbles, reinforcing the "Assistant" presence.
- **Chips/Badges:** Use small, 100px (pill) rounded badges for skills and job tags with low-contrast background colors (e.g., light blue or light gray) and dark text.